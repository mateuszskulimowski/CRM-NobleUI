export interface AuthenticationLayoutViewModel {
  readonly titleOne: string;
  readonly titleTwo: string;
  readonly description: string;
}
