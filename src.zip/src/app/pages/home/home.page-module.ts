import { NgModule } from '@angular/core';
import { HomePage } from './home.page';

@NgModule({
  imports: [],
  declarations: [HomePage],
  providers: [],
  exports: [HomePage],
})
export class HomePageModule {}
