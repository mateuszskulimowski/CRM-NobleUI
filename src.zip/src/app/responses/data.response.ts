export interface DataResponse<T> {
  readonly data: T;
}
