export interface RegisterResponse {
  readonly id: string;
  readonly number: string;
}
