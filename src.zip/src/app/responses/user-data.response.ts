export interface UserDataResponse<T> {
  readonly user: T;
}
