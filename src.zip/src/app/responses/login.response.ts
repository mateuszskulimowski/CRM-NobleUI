export interface LoginResponse {
  readonly accessToken: string;
  readonly refreshToken: string;
}
