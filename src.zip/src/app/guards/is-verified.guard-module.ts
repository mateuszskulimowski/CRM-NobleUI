import { NgModule } from '@angular/core';
import { IsVerifiedGuard } from './is-verified.guard';

@NgModule({
  imports: [],
  declarations: [],
  providers: [IsVerifiedGuard],
  exports: []
})
export class IsVerifiedGuardModule {
}
