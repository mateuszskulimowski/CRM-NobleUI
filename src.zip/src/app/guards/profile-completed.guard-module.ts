import { NgModule } from '@angular/core';
import { ProfileCompletedGuard } from './profile-completed.guard';

@NgModule({
  imports: [],
  declarations: [],
  providers: [ProfileCompletedGuard],
  exports: []
})
export class ProfileCompletedGuardModule {
}
