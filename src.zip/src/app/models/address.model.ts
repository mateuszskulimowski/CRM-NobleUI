export interface AddressModel {
  readonly street: string;
  readonly houseNumber: string;
  readonly zipCode: string;
  readonly city: string;
}
