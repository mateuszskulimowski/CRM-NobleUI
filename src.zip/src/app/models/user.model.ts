export interface UserModel {
  readonly id: string;
  readonly isVerified: boolean;
  readonly phone: string;
}
