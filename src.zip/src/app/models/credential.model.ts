export interface CredentialModel {
  readonly phone: string;
  readonly password: string;
}
