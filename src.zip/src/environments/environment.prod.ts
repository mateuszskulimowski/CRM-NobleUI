export const environment = {
  production: true,
  apiUrl: 'https://us-central1-courses-auth.cloudfunctions.net/phoneAuth',
};
